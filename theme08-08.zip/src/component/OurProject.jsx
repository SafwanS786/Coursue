import React from "react";

export default function OurProject() {
  return (
    <div className="main_our">
      <p id="para_our">Our Projects</p>
      <h1 id="head_our">Projects We've Delivered</h1>
    </div>
  );
}
